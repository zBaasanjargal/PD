﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;


namespace PD
{
    public partial class Form1 : Form
    {
        private SqlConnection sqlConnection;

        public Form1()
        {
            InitializeComponent();

            sqlConnection = new SqlConnection("Data Source=DESKTOP-0TPTI7A\\SQLEXPRESS;Initial Catalog=PDdb;Integrated Security=True");

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void Loginbutton_Click(object sender, EventArgs e)
        {
            string username = usernametxtbox.Text;
            string password = passwordtxtbox.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Нэвтрэх нэр болон нууц үг оруулна уу.");
                return;
            }

            try
            {
                sqlConnection.Open();

                string query = "SELECT * FROM users WHERE username = @username AND password = @password";
                using (SqlCommand command = new SqlCommand(query, sqlConnection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", password);
                    
                    SqlDataAdapter adp = new SqlDataAdapter(command);
                    DataTable dt = new DataTable();
                    
                    adp.Fill(dt);
                    
                    if(dt.Rows.Count > 0 )
                    {
                        Form2 form2 = new Form2();
                        form2.Show();
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password. Please try again.");
                        usernametxtbox.Clear();
                        passwordtxtbox.Clear();
                        usernametxtbox.Focus();
                    }
                }
                sqlConnection.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}
