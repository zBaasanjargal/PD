﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace PD
{
    public partial class Form2 : Form
    {
        string connectionString = "Data Source=DESKTOP-0TPTI7A\\SQLEXPRESS;Initial Catalog=PDdb;Integrated Security=True";
        SqlConnection sqlConnection;
        private int InsertedCount = 0;
        private int DeletedCount = 0;
        private int UpdatedCount = 0;
        string selectedTable;

        public Form2()
        {
            InitializeComponent();
            sqlConnection = new SqlConnection(connectionString);
            comboBox1.SelectedIndexChanged += ComboBox1_SelectedIndexChanged;
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selectedTable = comboBox1.SelectedItem.ToString();
            LoadData(selectedTable);
        }
        public void LoadData(string tableName)
        {
            if (string.IsNullOrEmpty(tableName))
            {
                return;
            }
            sqlConnection.Open();
            SqlCommand command = new SqlCommand($"SELECT * FROM [{tableName}]", sqlConnection);
            command.ExecuteNonQuery();

            DataTable dataTable = new DataTable();
            SqlDataAdapter adapter = new SqlDataAdapter(command);
            adapter.Fill(dataTable);

            datagridview1.DataSource = null;
            datagridview1.DataSource = dataTable;

            ChangePanelBasedOnSelectedTable(tableName);

            sqlConnection.Close();
        }


        private void ChangePanelBasedOnSelectedTable(string tableName)
        {
            switch (tableName.ToLower())
            {
                case "customers":
                    panel1.Visible = true;
                    panel2.Visible = false;
                    panel3.Visible = false;
                    break;

                case "products":
                    panel1.Visible = false;
                    panel2.Visible = true;
                    panel3.Visible = false;
                    break;

                case "orders":
                    panel1.Visible = false;
                    panel2.Visible = false;
                    panel3.Visible = true;  
                    break;

                case "orderdetails":
                    // Add logic for orderdetails panel
                    // Example: panel5.Visible = true; panel6.Visible = false;
                    break;

                case "employees":
                    // Add logic for employees panel
                    // Example: panel7.Visible = true; panel8.Visible = false;
                    break;

                case "suppliers":
                    // Add logic for suppliers panel
                    // Example: panel9.Visible = true; panel10.Visible = false;
                    break;

                default:
                    // Handle unknown table names or add more cases as needed
                    break;
            }
        }


        private void Form2_Load(object sender, EventArgs e)
        {
            LoadData(selectedTable);
            this.FormClosing += Form2_FormClosing;
            panel1.Visible = false;
            panel2.Visible = false;
            panel3.Visible = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }


        private void datagridview1_CellEnter(object sender, DataGridViewCellEventArgs e)
        {
        }

        private void deletebttn_Click(object sender, EventArgs e)
        {
            
        }

        private void datagridview1_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void insertbttn_Click_1(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(textBox1.Text))
                {
                    MessageBox.Show("ID хэсэг хоосон байна.");
                    return;
                }
                using (SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM customers WHERE customer_id = @id", sqlConnection))
                {
                    checkCmd.Parameters.AddWithValue("@id", textBox1.Text);

                    sqlConnection.Open();
                    int existingRecords = (int)checkCmd.ExecuteScalar();
                    sqlConnection.Close();

                    if (existingRecords > 0)
                    {
                        MessageBox.Show("Customer with the same ID already exists. Please choose a different ID.");
                        return;
                    }
                }

                using (SqlCommand insertCmd = new SqlCommand("INSERT INTO customers (customer_id, customer_name, contact_person, phone_number, email) VALUES (@id, @name, @contact, @phone, @email)", sqlConnection))
                {
                    insertCmd.Parameters.AddWithValue("@id", textBox1.Text);
                    insertCmd.Parameters.AddWithValue("@name", textBox2.Text);
                    insertCmd.Parameters.AddWithValue("@contact", textBox3.Text);
                    insertCmd.Parameters.AddWithValue("@phone", textBox4.Text);
                    insertCmd.Parameters.AddWithValue("@email", textBox5.Text);

                    sqlConnection.Open();
                    int rowsAffected = insertCmd.ExecuteNonQuery();
                    sqlConnection.Close();

                    if (rowsAffected > 0)
                    {
                        InsertedCount++;
                        MessageBox.Show("Successfully inserted.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                textBox1.Focus();
            }
        }

        private void updatebttn_Click_1(object sender, EventArgs e)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE customers SET " +
                    "customer_name=@name, contact_person=@contact, phone_number=@phone, email=@email" +
                    " WHERE customer_id = @id", sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@id", Convert.ToInt32(textBox1.Text));
                    cmd.Parameters.AddWithValue("@name", textBox2.Text);
                    cmd.Parameters.AddWithValue("@contact", textBox3.Text);
                    cmd.Parameters.AddWithValue("@phone", textBox4.Text);
                    cmd.Parameters.AddWithValue("@email", textBox5.Text);

                    sqlConnection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    sqlConnection.Close();

                    if (rowsAffected > 0)
                    {
                        UpdatedCount++;
                        MessageBox.Show("Successfully updated.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                sqlConnection.Close();
                LoadData(selectedTable);
            }
        }

        private void deletebttn_Click_1(object sender, EventArgs e)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("DELETE FROM customers WHERE customer_id=@id", sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@id", Convert.ToInt32(textBox1.Text));

                    sqlConnection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    sqlConnection.Close();

                    if (rowsAffected > 0)
                    {
                        DeletedCount++;
                        MessageBox.Show("Successfully deleted.");
                    }
                    else
                    {
                        MessageBox.Show("No records found for the given customer ID.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                sqlConnection.Close();
                textBox1.Clear();
                textBox1.Focus();
                LoadData(selectedTable);
            }
        }
        private void Form2_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show("Тайлан харах уу?", "Exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                MessageBox.Show($"Inserted: {InsertedCount} \nDeleted: {DeletedCount} \nUpdated: {UpdatedCount} ");
            }
        }

        private void exitbttn_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }


        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrEmpty(textBox9.Text))
                {
                    MessageBox.Show("ID хэсэг хоосон байна.");
                    return;
                }
                using (SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM products WHERE product_id = @pid", sqlConnection))
                {
                    checkCmd.Parameters.AddWithValue("@pid", textBox9.Text);
                    sqlConnection.Open();
                    int existingRecords = (int)checkCmd.ExecuteScalar();
                    sqlConnection.Close();

                    if (existingRecords > 0)
                    {
                        MessageBox.Show("Product with the same ID already exists. Please choose a different ID.");
                        return;
                    }
                }

                using (SqlCommand insertCmd = new SqlCommand("INSERT INTO products (product_id, product_name, category, supplier_id, price) VALUES (@pid, @pname, @category, @suppid, @price)", sqlConnection))
                {
                    insertCmd.Parameters.AddWithValue("@pid", textBox9.Text); 
                    insertCmd.Parameters.AddWithValue("@pname", textBox8.Text);
                    insertCmd.Parameters.AddWithValue("@category", textBox10.Text);
                    insertCmd.Parameters.AddWithValue("@suppid", textBox6.Text);
                    insertCmd.Parameters.AddWithValue("@price", textBox7.Text);

                    sqlConnection.Open();
                    int rowsAffected = insertCmd.ExecuteNonQuery();
                    sqlConnection.Close();

                    if (rowsAffected > 0)
                    {
                        InsertedCount++;
                        MessageBox.Show("Successfully inserted.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                sqlConnection.Close();
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox9.Clear();
                textBox10.Clear();
                textBox9.Focus();
            }
        }



        private void datagridview1_CellClick_1(object sender, DataGridViewCellEventArgs e)
        {
            if (panel1.Visible)
            {
                textBox1.Text = datagridview1.CurrentRow.Cells[0].Value.ToString();
                textBox2.Text = datagridview1.CurrentRow.Cells[1].Value.ToString();
                textBox3.Text = datagridview1.CurrentRow.Cells[2].Value.ToString();
                textBox4.Text = datagridview1.CurrentRow.Cells[3].Value.ToString();
                textBox5.Text = datagridview1.CurrentRow.Cells[4].Value.ToString();
            }
            else if (panel2.Visible)
            {
                textBox9.Text = datagridview1.CurrentRow.Cells[0].Value.ToString();
                textBox8.Text = datagridview1.CurrentRow.Cells[1].Value.ToString();
                textBox10.Text = datagridview1.CurrentRow.Cells[2].Value.ToString();
                textBox6.Text = datagridview1.CurrentRow.Cells[3].Value.ToString();
                textBox7.Text = datagridview1.CurrentRow.Cells[4].Value.ToString();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("UPDATE products SET " +
                    "product_name=@pname, category=@category, supplier_id=@suppid, price=@price" +
                    " WHERE product_id = @pid", sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@pid", Convert.ToInt32(textBox9.Text));
                    cmd.Parameters.AddWithValue("@pname", textBox8.Text);
                    cmd.Parameters.AddWithValue("@category", textBox10.Text);
                    cmd.Parameters.AddWithValue("@suppid", textBox6.Text);
                    cmd.Parameters.AddWithValue("@price", textBox7.Text);

                    sqlConnection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    sqlConnection.Close();

                    if (rowsAffected > 0)
                    {
                        UpdatedCount++;
                        MessageBox.Show("Successfully updated.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                sqlConnection.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlCommand cmd = new SqlCommand("DELETE FROM products WHERE product_id=@id", sqlConnection))
                {
                    cmd.Parameters.AddWithValue("@id", Convert.ToInt32(textBox9.Text));

                    sqlConnection.Open();
                    int rowsAffected = cmd.ExecuteNonQuery();
                    sqlConnection.Close();

                    if (rowsAffected > 0)
                    {
                        DeletedCount++;
                        MessageBox.Show("Successfully deleted.");
                    }
                    else
                    {
                        MessageBox.Show("No records found for the given customer ID.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                sqlConnection.Close();
                textBox9.Clear();
                textBox9.Focus();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
